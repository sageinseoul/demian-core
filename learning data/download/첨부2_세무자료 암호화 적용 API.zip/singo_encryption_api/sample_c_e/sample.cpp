#include <stdio.h>
#include "fcrypt_e.h"

int ReadFile(char* pszFilePath, BYTE** buf, int* psize);

int main(int argc, char *argv[])
{
	int nRet = 0;
	int nfsize = 0;
	BYTE *buf = NULL;
	char *pszInputPlainPath = "./data/test.txt";
	char *pszOutputEncPath  = "./data/test.txt.enc";
	char *pszOutputEncDPath = "./data/test_d.txt.enc";
	char *pszPwd            = "88888888";

	printf("Test START =========================\n");

	HWND hWnd = 0;			// window�� �ִ� ���α׷������� �ݵ�� window�� handle�� ȹ���ؾ� �Ѵ�.

	nRet = DSFC_EncryptFile(hWnd, pszInputPlainPath, pszOutputEncPath, pszPwd, DSFC_OPT_OVERWRITE_OUTPUT);
	printf("DSFC_EncryptFile() return %d\n", nRet);
	if (nRet != 0) goto __FINALLY;
	
	nRet = ReadFile(pszInputPlainPath, &buf, &nfsize);
	if (nRet != 0) goto __FINALLY;
	
	nRet = DSFC_EncryptData(hWnd, (char*)buf, nfsize, pszOutputEncDPath, pszPwd, DSFC_OPT_OVERWRITE_OUTPUT);
	printf("DSFC_EncryptData() return %d\n", nRet);
	if (nRet != 0) goto __FINALLY;
	
__FINALLY:
	if (buf) delete [] buf;

	printf("Test END   =========================\n");
	
	return 0;
}

int ReadFile(char* pszFilePath, BYTE** buf, int* psize)
{
	FILE *fp = fopen(pszFilePath, "rb");
	if (!fp) return -1;
	
	int nRet = fseek(fp, 0, SEEK_SET);
	if (nRet != 0) return -2;
	
	nRet = fseek(fp, 0, SEEK_END);
	if (nRet != 0) return -3;
	
	int len = ftell(fp);
	
	// reset position.
	nRet = fseek(fp, 0, SEEK_SET);
	if (nRet != 0) return -4;
	
	BYTE *pbuf = new BYTE[len];
	if (!pbuf) return -5;
	
	nRet = fread(pbuf, 1, len, fp);
	if (nRet != len)
	{
		delete [] pbuf;
		return -6;
	}
	
	*buf   = pbuf;
	*psize = len;
	
	fclose(fp);
	
	return 0;
}
