﻿Imports System.IO
Imports System.Runtime.InteropServices

'----------------------------------------------
' 전체적인 설명
'
' 1. 아래 샘플코드의 CASE1, CASE2 중 적절한 API를 선택해서 사용하십시오.
' 2. fcrypt_es.dll v1.1.0.0 이하 는 CASE2를 지원하지 않습니다.
' 3. 세무자료 암호화 API를 사용하기 위해 반드시 추가되어야 할 코드는 '@'로 시작하는
'    주석이 추가되어 있습니다.
'----------------------------------------------

Module sample_vb

    '@ Win32 API형식으로 정의된 fcrypt_es.dll 을 사용하기 위한 Win32 클래스를 정의합니다.
    Public Class FCrypt
        '파일을 읽어서 암호화한 후 파일로 저장하는 API
        <DllImport("fcrypt_es.dll", CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.StdCall)> _
        Public Shared Function DSFC_EncryptFile _
                                        (ByVal hWnd As Integer, ByVal pszPlainFilePathName As String, ByVal pszEncFilePathName As String, _
                                         ByVal pszPassword As String, ByVal nOption As Integer) As Integer
        End Function

        '데이터를 입력 받아서 암호화한 후 파일로 저장하는 API
        <DllImport("fcrypt_es.dll", CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.StdCall)> _
        Public Shared Function DSFC_EncryptData _
                                        (ByVal hWnd As Integer, ByVal pszPlainData As IntPtr, ByVal dataLen As Integer, ByVal pszEncFilePathName As String, _
                                         ByVal pszPassword As String, ByVal nOption As Integer) As Integer
        End Function
    End Class

    Sub Main()

        '아래의 2종류의 API 중 필요한 것을 선택해서 사용하시기 바랍니다.

        Dim hWnd As Long
        Dim inputData() As Byte
        Dim nLen As Long
        Dim inputPath As String
        Dim outputPath As String
        Dim outputPath2 As String
        Dim password As String
        Dim DSFC_OPT_OVERWRITE_OUTPUT As Integer

        Dim nRet As Integer
        Dim objStream As FileStream

        '@ API를 공통으로 호출하기 위한 변수를 초기화 합니다.
        hWnd = 0                                'DLL을 호출하는 window의 handle
        nRet = 0                                'DSFC_~() 의 리턴 값

        inputPath = "./data/test.txt"
        outputPath = "./data/test.txt.enc"
        outputPath2 = "./data/test.txt.denc"

        password = "88888888"

        DSFC_OPT_OVERWRITE_OUTPUT = 1

        '----------------------------------------------
        ' CASE 1. 파일을 읽어서 암호화하는 기능
        '----------------------------------------------
        nRet = FCrypt.DSFC_EncryptFile(hWnd, inputPath, outputPath, password, DSFC_OPT_OVERWRITE_OUTPUT)
        MsgBox("DSFC_EncryptFile() return : " + CStr(nRet))


        '----------------------------------------------
        ' CASE 2. 데이터를 입력 받아서 암호화 하는 기능
        '----------------------------------------------
        '1) 샘플코드에서는 파일을 읽어서 메모리의 데이터로 활용합니다.
        '   실제 신고자료암호화 시에는 메모리상에 만들어진 신고자료 파일을 바로 암호화하기 때문에
        '   파일을 읽는 코드는 필요하지 않습니다.
        Try
            objStream = New FileStream(inputPath, FileMode.Open)
            Dim binReader As New BinaryReader(objStream)

            nLen = objStream.Length
            inputData = New Byte(nLen) {}
            binReader.Read(inputData, 0, nLen)
            binReader.Close()
        Catch E As Exception
            Console.WriteLine(E.Message)
            Return
        End Try

        Dim ptr As IntPtr

        Try
            '2) 메모리의 값이 DSFC_EncryptData로 전달되기 전에 IntPtr 형태로 변환되어야 합니다.
            '   Byte()의 경우 아래와 같이 변환합니다.
            Dim size As Integer

            size = Marshal.SizeOf(inputData(0)) * nLen
            ptr = Marshal.AllocHGlobal(size)

            Marshal.Copy(inputData, 0, ptr, nLen)

            '3) 메모리의 값을 바로 암호화해서 파일로 저장
            nRet = FCrypt.DSFC_EncryptData(hWnd, ptr, nLen, outputPath2, password, DSFC_OPT_OVERWRITE_OUTPUT)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        Finally
            '4) 반드시 IntPtr 해제
            Marshal.FreeHGlobal(ptr)
        End Try

        MsgBox("DSFC_EncryptData() return : " + CStr(nRet))

    End Sub

End Module
