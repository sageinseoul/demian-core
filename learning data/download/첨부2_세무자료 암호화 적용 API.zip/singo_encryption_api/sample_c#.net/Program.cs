﻿//
// '@' 표시가된 부분은 DLL을 사용하기 위해 추가된 부분입니다.
//

using System;
using System.IO;
using System.Runtime.InteropServices;   // @. DLL을 import 하기위해 추가하는 namespace 

namespace sample_cs
{
    class Program
    {
        // @. DLL 선언부
        //[[
        [DllImport("fcrypt_e.dll", EntryPoint = "DSFC_EncryptFile", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        private static extern int DSFC_EncryptFile(int hWnd, string inputPath, string outputPath, string password, int option);

        [DllImport("fcrypt_e.dll", EntryPoint = "DSFC_EncryptData", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        private static extern int DSFC_EncryptData(int hWnd, byte[] inputData, int dataLen, string outputPath, string password, int option);
        //]]

        public static void Main(string[] args)
        {
            int handle        = 0;
            string inputPath  = "./data/test.txt";
            string outputPath = "./data/test.txt.enc";
            string outputPath2 = "./data/test.txt.denc";
            string password = "88888888";
            int option        = 1;

            Console.WriteLine("C# DSFC_EncryptFile(); Test ====================");
            // @. 호출부
            int ret = DSFC_EncryptFile(handle, inputPath, outputPath, password, option);
            Console.WriteLine("DSFC_EncryptFile(); return code : {0}", ret);

            Console.WriteLine("C# DSFC_EncryptData(); Test ====================");
            // 데이터 파일 읽기
            FileStream fs  = new FileStream(inputPath, FileMode.Open);
            BinaryReader r = new BinaryReader(fs);
            int dataLen = (int)fs.Length;
            byte[] buf = r.ReadBytes((int)fs.Length);
            fs.Close();

            // @. 호출부
            ret = DSFC_EncryptData(handle, buf, dataLen, outputPath2, password, option);
            Console.WriteLine("DSFC_EncryptData(); return code : {0}", ret);
        }
    }
}
