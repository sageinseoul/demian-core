//
// fcrypt_e.h
//

#ifdef WIN32
#  ifdef FCRYPT_EXPORTS
#    define FCRYPT_API extern "C" __declspec(dllexport)
#  else
#    ifdef __cplusplus
#      define FCRYPT_API extern "C" __declspec(dllimport)
#    else
#      define FCRYPT_API __declspec(dllimport)
#    endif
#  endif
#else
#  ifdef __cplusplus
#    define FCRYPT_API extern "C"
#  else
#    define FCRYPT_API
#  endif
#endif

#include <windows.h>
#include "fcrypt_error.h"


//-----------------------------------------------------------------------------
// OPTIONS.
//-----------------------------------------------------------------------------

#define DSFC_OPT_OVERWRITE_OUTPUT						1


//-----------------------------------------------------------------------------
// FUNCTIONS.
//-----------------------------------------------------------------------------

FCRYPT_API int cdecl DSFC_EncryptFile(HWND hWnd, char *pszPlainFilePathName, char *pszEncFilePathName, char *pszPassword, UINT nOption);
FCRYPT_API int cdecl DSFC_EncryptData(HWND hWnd, char *pszPlainData, UINT nDataSize, char *pszEncFilePathName, char *pszPassword, UINT nOption);
